public class TestZookeeper {

	public static void main(String[] args) 
		Mammal = new Mammal();
		Gorilla = new Gorilla();
		Bat = new Bat();
		
		
		Gorilla.throwSomething();
		Gorilla.throwSomething();
		Gorilla.throwSomething();
		
		Gorilla.eatBananas();
		Gorilla.eatBananas();
		
		Gorilla.climb();
		
		Gorilla.displayEnergy();
		
		
		Bat.attackTown();
		Bat.attackTown();
		Bat.attackTown();
		
		Bat.eatHumans();
		Bat.eatHumans();
		
		Bat.fly();
		Bat.fly();
		
		Bat.displayEnergy();
	}

}