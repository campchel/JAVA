/**
 * 
 */
/**
 * @author ccche
 *
 */
module Daikichi {
}